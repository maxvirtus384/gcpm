# Green Code Project Manager (GCPM) 🌿

Green Code Project Manager is a full-stack web application designed to help software teams manage projects and tasks while tracking their environmental impact. It integrates traditional project management tools like Kanban boards with sustainability intelligence, including energy consumption estimation and carbon emission tracking.

## 🚀 Key Features

- **Sustainability Intelligence**: Real-time energy consumption estimation (kWh) and carbon footprint tracking (kg CO₂e) for projects and tasks.
- **Project Management**: Interactive Kanban board with task assignment, status tracking (`todo`, `in_progress`, `done`), and deadline management.
- **Role-Based Portals**:
  - **User Portal**: Manage personal projects, tasks, and view individual sustainability metrics.
  - **Admin Portal**: System-wide monitoring, user management (CRUD), and global sustainability analytics across all projects.
- **Collaboration**: Real-time project-specific chat system and task comments.
- **Reporting**: Export detailed sustainability reports in TXT or PDF formats.
- **Modern UI**: Immersive, dark-themed dashboard with responsive charts (Chart.js).

## 🛠️ Tech Stack

- **Frontend**: Vanilla JavaScript, HTML5, CSS3, Chart.js, jsPDF.
- **Backend**: Node.js, Express.js.
- **Database**: MongoDB (via Mongoose ODM).
- **Security**: JWT (JSON Web Tokens) for authentication and bcryptjs for password hashing.

## ⚙️ Local Setup & Installation

1. **Clone the Repository**:
   ```bash
   git clone <repository-url>
   cd GCPM
   ```

2. **Configure Environment Variables**:
   Create a `.env` file in the `backend` folder:
   ```env
   PORT=3001
   MONGODB_URI=mongodb://localhost:27017/greencode
   JWT_SECRET=your_secure_random_string
   NODE_ENV=development
   ```

3. **Install Dependencies**:
   ```bash
   cd backend
   npm install
   ```

4. **Start the Server**:
   ```bash
   npm start
   ```

5. **Access the App**:
   Open your browser and navigate to `http://localhost:3001`.

## 📂 Project Structure

- `/` : Frontend assets (`index.html`, `script.js`, `styles.css`, `api.js`).
- `/backend` : Express server and API logic.
  - `/models` : Mongoose schemas (User, Project, Booking, etc.).
  - `/routes` : API endpoints (Auth, Projects, Admin, etc.).
  - `/middleware` : Authentication and authorization logic.
  - `server.js` : Main entry point.
- `/uploads` : Local storage for task file attachments.

## 📝 Usage Notes

- **Admin Access**: Register a new account and select "Admin" to access the specialized management dashboard.
- **Sustainability Metrics**: Energy and emission values are calculated based on estimated activity hours and task complexity using industry-standard heuristic factors.

## 📜 License

Built with sustainability in mind. © 2026 Green Code PM.
