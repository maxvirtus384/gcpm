/**
 * Green Code PM – Backend API Client
 * Communicates with the Express + MongoDB backend.
 */

const API_BASE_URL = "/api"; // Same origin
const STORAGE_SESSION = "gcp_session_v2";

/**
 * Helper to handle fetch responses
 */
async function handleResponse(response) {
  const data = await response.json();
  if (!response.ok) {
    const error = new Error(data.error || "Something went wrong");
    error.status = response.status;
    error.data = data;
    throw error;
  }
  return data;
}

/**
 * Internal helper to get the current session from localStorage
 */
function _getInternalSession() {
  const session = localStorage.getItem(STORAGE_SESSION);
  try {
    return session ? JSON.parse(session) : null;
  } catch {
    return null;
  }
}

/**
 * Get headers for authenticated requests
 */
function getAuthHeaders() {
  const session = _getInternalSession();
  const headers = {
    "Content-Type": "application/json",
  };
  if (session && session.token) {
    headers["Authorization"] = `Bearer ${session.token}`;
  }
  return headers;
}

const api = {
  /**
   * Register a new user
   */
  async register(name, email, password, role = "user") {
    const response = await fetch(`${API_BASE_URL}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password, role }),
    });
    const data = await handleResponse(response);
    localStorage.setItem(STORAGE_SESSION, JSON.stringify(data));
    return data;
  },

  /**
   * Login a user
   */
  async login(email, password) {
    const response = await fetch(`${API_BASE_URL}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const data = await handleResponse(response);
    localStorage.setItem(STORAGE_SESSION, JSON.stringify(data));
    return data;
  },

  /**
   * Logout a user
   */
  logout() {
    localStorage.removeItem(STORAGE_SESSION);
  },

  /**
   * Get the current session
   */
  getSession() {
    return _getInternalSession();
  },

  /**
   * Get all projects for the current user
   */
  async getProjects() {
    const response = await fetch(`${API_BASE_URL}/projects`, {
      headers: getAuthHeaders(),
    });
    return await handleResponse(response);
  },

  /**
   * Create a new project
   */
  async createProject({ name, description, activity, deadline, githubRepo }) {
    const response = await fetch(`${API_BASE_URL}/projects`, {
      method: "POST",
      headers: getAuthHeaders(),
      body: JSON.stringify({ name, description, activity, deadline, githubRepo }),
    });
    return await handleResponse(response);
  },

  /**
   * Add a task to a project (supports file upload)
   */
  async addTask(projectId, formData) {
    const session = _getInternalSession();
    const headers = {};
    if (session && session.token) {
      headers["Authorization"] = `Bearer ${session.token}`;
    }
    // Note: Do NOT set Content-Type for FormData, browser will do it with boundary
    const response = await fetch(`${API_BASE_URL}/projects/${projectId}/tasks`, {
      method: "POST",
      headers,
      body: formData,
    });
    return await handleResponse(response);
  },

  /**
   * Update a task status or other fields
   */
  async updateTask(projectId, taskId, updates) {
    const response = await fetch(`${API_BASE_URL}/projects/${projectId}/tasks/${taskId}`, {
      method: "PATCH",
      headers: getAuthHeaders(),
      body: JSON.stringify(updates),
    });
    return await handleResponse(response);
  },

  /**
   * Add a comment to a task
   */
  async addTaskComment(projectId, taskId, text) {
    const response = await fetch(`${API_BASE_URL}/projects/${projectId}/tasks/${taskId}/comments`, {
      method: "POST",
      headers: getAuthHeaders(),
      body: JSON.stringify({ text }),
    });
    return await handleResponse(response);
  },

  /**
   * Get project chat messages
   */
  async getProjectChat(projectId) {
    const response = await fetch(`${API_BASE_URL}/projects/${projectId}/chat`, {
      headers: getAuthHeaders(),
    });
    return await handleResponse(response);
  },

  /**
   * Send a project chat message
   */
  async sendProjectChat(projectId, text) {
    const response = await fetch(`${API_BASE_URL}/projects/${projectId}/chat`, {
      method: "POST",
      headers: getAuthHeaders(),
      body: JSON.stringify({ text }),
    });
    return await handleResponse(response);
  },

  /**
   * Book a discovery call
   */
  async bookDiscoveryCall(bookingData) {
    const response = await fetch(`${API_BASE_URL}/bookings`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(bookingData),
    });
    return await handleResponse(response);
  },

  /**
   * Submit a query
   */
  async submitQuery(queryData) {
    const response = await fetch(`${API_BASE_URL}/queries`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(queryData),
    });
    return await handleResponse(response);
  },

  /**
   * Admin: Get all bookings
   */
  async getAdminBookings() {
    const response = await fetch(`${API_BASE_URL}/admin/bookings`, {
      headers: getAuthHeaders(),
    });
    return await handleResponse(response);
  },

  /**
   * Admin: Get all queries
   */
  async getAdminQueries() {
    const response = await fetch(`${API_BASE_URL}/admin/queries`, {
      headers: getAuthHeaders(),
    });
    return await handleResponse(response);
  },

  /**
   * Admin: Get all projects (global view)
   */
  async getAdminProjects() {
    const response = await fetch(`${API_BASE_URL}/admin/projects`, {
      headers: getAuthHeaders(),
    });
    return await handleResponse(response);
  },

  /**
   * Admin: Get all users
   */
  async getAdminUsers() {
    const response = await fetch(`${API_BASE_URL}/admin/users`, {
      headers: getAuthHeaders(),
    });
    return await handleResponse(response);
  },

  /**
   * Admin: Update user
   */
  async updateAdminUser(userId, userData) {
    const response = await fetch(`${API_BASE_URL}/admin/users/${userId}`, {
      method: "PATCH",
      headers: getAuthHeaders(),
      body: JSON.stringify(userData),
    });
    return await handleResponse(response);
  },

  /**
   * Admin: Delete user
   */
  async deleteAdminUser(userId) {
    const response = await fetch(`${API_BASE_URL}/admin/users/${userId}`, {
      method: "DELETE",
      headers: getAuthHeaders(),
    });
    return await handleResponse(response);
  },

  /**
   * Admin: Get system stats
   */
  async getAdminStats() {
    const response = await fetch(`${API_BASE_URL}/admin/stats`, {
      headers: getAuthHeaders(),
    });
    return await handleResponse(response);
  },
};

// Expose api to global scope
window.api = api;
