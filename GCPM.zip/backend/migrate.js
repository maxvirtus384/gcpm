require("dotenv").config();
const mongoose = require("mongoose");
const fs = require("fs");
const path = require("path");
const User = require("./models/User");
const Project = require("./models/Project");

const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017/greencode";

async function migrate() {
  try {
    await mongoose.connect(MONGODB_URI);
    console.log("Connected to MongoDB for migration");

    const dataDir = path.join(__dirname, "data");
    const usersFile = path.join(dataDir, "users.json");
    const projectsFile = path.join(dataDir, "projects.json");

    // Migrate Users
    if (fs.existsSync(usersFile)) {
      const users = JSON.parse(fs.readFileSync(usersFile, "utf8"));
      for (const u of users) {
        const existing = await User.findOne({ email: u.email });
        if (!existing) {
          const newUser = new User({
            name: u.name,
            email: u.email,
            passwordHash: u.passwordHash,
            createdAt: u.createdAt,
          });
          await newUser.save();
          console.log(`Migrated user: ${u.email}`);
        }
      }
    }

    // Migrate Projects
    if (fs.existsSync(projectsFile)) {
      const projects = JSON.parse(fs.readFileSync(projectsFile, "utf8"));
      for (const p of projects) {
        const newProject = new Project({
          ownerEmail: p.ownerEmail,
          name: p.name,
          description: p.description,
          estimatedActivityHours: p.estimatedActivityHours,
          createdAt: p.createdAt,
          tasks: p.tasks.map(t => ({
            title: t.title,
            assignee: t.assignee,
            status: t.status,
            estimatedHours: t.estimatedHours,
          })),
        });
        await newProject.save();
        console.log(`Migrated project: ${p.name}`);
      }
    }

    console.log("Migration completed successfully");
    process.exit(0);
  } catch (err) {
    console.error("Migration error:", err);
    process.exit(1);
  }
}

migrate();
