const express = require("express");
const Query = require("../models/Query");
const { authMiddleware, adminMiddleware } = require("../middleware/auth");

const router = express.Router();

// Public: Submit a query
router.post("/", async (req, res) => {
  try {
    const { name, email, message } = req.body;
    if (!name || !email || !message) {
      return res.status(400).json({ error: "Name, email and message are required" });
    }
    const newQuery = new Query({ name, email, message });
    await newQuery.save();
    res.status(201).json({ message: "Query submitted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

// Admin: Get all queries
router.get("/", authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const queries = await Query.find().sort({ createdAt: -1 });
    res.json(queries);
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
