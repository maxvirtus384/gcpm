const express = require("express");
const multer = require("multer");
const path = require("path");
const Project = require("../models/Project");
const ChatMessage = require("../models/ChatMessage");
const { authMiddleware, adminMiddleware } = require("../middleware/auth");

const router = express.Router();
router.use(authMiddleware);

// Multer setup - Use /tmp for Vercel or memory storage if needed
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = process.env.NODE_ENV === "production" ? '/tmp' : 'uploads/';
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

// Ensure uploads directory exists (Only in local development)
const fs = require('fs');
if (process.env.NODE_ENV !== "production") {
  if (!fs.existsSync('uploads/')) fs.mkdirSync('uploads/');
}

// Helper to add activity
async function addActivity(project, userName, action, details) {
  project.activities.push({ userName, action, details });
  if (project.activities.length > 50) project.activities.shift(); // Keep last 50
  await project.save();
}

router.get("/", async (req, res) => {
  try {
    const list = await Project.find({ ownerEmail: req.user.email });
    // Map _id to id for frontend compatibility
    const formattedList = list.map(p => ({
      ...p.toObject(),
      id: p._id,
      tasks: p.tasks.map(t => ({ ...t.toObject(), id: t._id }))
    }));
    return res.json(formattedList);
  } catch (error) {
    console.error("Fetch projects error:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/", async (req, res) => {
  try {
    const { name, description, activity, deadline, githubRepo } = req.body || {};
    const trimmedName = (name || "").trim();
    const descriptionStr = (description || "").trim();
    const activityHours = Number(activity) || 0;

    if (!trimmedName) {
      return res.status(400).json({ error: "Project name is required" });
    }

    const newProject = new Project({
      ownerEmail: req.user.email,
      name: trimmedName,
      description: descriptionStr,
      estimatedActivityHours: activityHours,
      deadline: deadline ? new Date(deadline) : undefined,
      githubRepo: githubRepo || undefined,
      tasks: [],
      activities: [{ userName: req.user.name, action: "Created project", details: trimmedName }]
    });

    await newProject.save();
    return res.status(201).json({ ...newProject.toObject(), id: newProject._id });
  } catch (error) {
    console.error("Create project error:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const project = await Project.findOne({
      _id: req.params.id,
      ownerEmail: req.user.email
    });
    if (!project) return res.status(404).json({ error: "Project not found" });
    return res.json({
      ...project.toObject(),
      id: project._id,
      tasks: project.tasks.map(t => ({ ...t.toObject(), id: t._id }))
    });
  } catch (error) {
    console.error("Get project error:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/:id/tasks", upload.single('file'), async (req, res) => {
  try {
    const { id } = req.params;
    const { title, assignee, status, hours, deadline } = req.body || {};
    const trimmedTitle = (title || "").trim();
    const assigneeStr = (assignee || "").trim();
    const statusVal = ["todo", "in_progress", "done"].includes(status) ? status : "todo";
    const estimatedHours = hours != null && hours !== "" ? Number(hours) : null;

    if (!trimmedTitle) {
      return res.status(400).json({ error: "Task title is required" });
    }

    const project = await Project.findOne({
      _id: id,
      ownerEmail: req.user.email
    });
    if (!project) return res.status(404).json({ error: "Project not found" });

    const newTask = {
      title: trimmedTitle,
      assignee: assigneeStr || undefined,
      status: statusVal,
      estimatedHours,
      deadline: deadline ? new Date(deadline) : undefined,
      files: req.file ? [{ name: req.file.originalname, url: `/uploads/${req.file.filename}` }] : []
    };
    project.tasks.push(newTask);
    await addActivity(project, req.user.name, "Added task", trimmedTitle);
    
    const savedTask = project.tasks[project.tasks.length - 1];
    return res.status(201).json({ ...savedTask.toObject(), id: savedTask._id });
  } catch (error) {
    console.error("Add task error:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/:projectId/tasks/:taskId", async (req, res) => {
  try {
    const { projectId, taskId } = req.params;
    const { status, title, assignee, hours } = req.body || {};

    const project = await Project.findOne({
      _id: projectId,
      ownerEmail: req.user.email
    });
    if (!project) return res.status(404).json({ error: "Project not found" });

    const task = project.tasks.id(taskId);
    if (!task) return res.status(404).json({ error: "Task not found" });

    const oldStatus = task.status;
    if (status && ["todo", "in_progress", "done"].includes(status)) {
      task.status = status;
    }
    if (title !== undefined) task.title = title.trim();
    if (assignee !== undefined) task.assignee = assignee.trim();
    if (hours !== undefined) task.estimatedHours = Number(hours) || 0;
    
    if (oldStatus !== task.status) {
      await addActivity(project, req.user.name, "Updated task status", `${task.title}: ${oldStatus} -> ${task.status}`);
    } else {
      await project.save();
    }
    
    return res.json({ ...task.toObject(), id: task._id });
  } catch (error) {
    console.error("Update task error:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

// Task comments
router.post("/:projectId/tasks/:taskId/comments", async (req, res) => {
  try {
    const { projectId, taskId } = req.params;
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: "Comment text is required" });

    const project = await Project.findOne({ _id: projectId, ownerEmail: req.user.email });
    if (!project) return res.status(404).json({ error: "Project not found" });

    const task = project.tasks.id(taskId);
    if (!task) return res.status(404).json({ error: "Task not found" });

    task.comments.push({
      authorName: req.user.name,
      authorEmail: req.user.email,
      text: text.trim()
    });
    
    await addActivity(project, req.user.name, "Commented on task", task.title);
    return res.status(201).json(task.comments[task.comments.length - 1]);
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

// Project Chat
router.get("/:id/chat", async (req, res) => {
  try {
    const messages = await ChatMessage.find({ projectId: req.params.id }).sort({ createdAt: 1 }).limit(100);
    res.json(messages);
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/:id/chat", async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: "Message text is required" });

    const project = await Project.findOne({ _id: req.params.id, ownerEmail: req.user.email });
    if (!project) return res.status(404).json({ error: "Project not found" });

    const newMessage = new ChatMessage({
      projectId: project._id,
      authorName: req.user.name,
      authorEmail: req.user.email,
      text: text.trim()
    });
    await newMessage.save();
    res.status(201).json(newMessage);
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

// Admin: Get all projects (global view)
router.get("/all", authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const list = await Project.find();
    const formattedList = list.map(p => ({
      ...p.toObject(),
      id: p._id,
      tasks: p.tasks.map(t => ({ ...t.toObject(), id: t._id }))
    }));
    return res.json(formattedList);
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
