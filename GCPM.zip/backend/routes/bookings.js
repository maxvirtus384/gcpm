const express = require("express");
const Booking = require("../models/Booking");
const { authMiddleware, adminMiddleware } = require("../middleware/auth");

const router = express.Router();

// Public: Submit a discovery call booking
router.post("/", async (req, res) => {
  try {
    const { name, email, company, message, timeline } = req.body;
    if (!name || !email) {
      return res.status(400).json({ error: "Name and email are required" });
    }
    const newBooking = new Booking({ name, email, company, message, timeline });
    await newBooking.save();
    res.status(201).json({ message: "Booking submitted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

// Admin: Get all bookings
router.get("/", authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const bookings = await Booking.find().sort({ createdAt: -1 });
    res.json(bookings);
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
