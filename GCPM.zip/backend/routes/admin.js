const express = require("express");
const User = require("../models/User");
const Project = require("../models/Project");
const Booking = require("../models/Booking");
const Query = require("../models/Query");
const { authMiddleware, adminMiddleware } = require("../middleware/auth");
const bcrypt = require("bcryptjs");

const router = express.Router();

// All routes here require admin privileges
router.use(authMiddleware, adminMiddleware);

/**
 * User Management
 */

// Get all users
router.get("/users", async (req, res) => {
  try {
    const users = await User.find({}, "-passwordHash").sort({ createdAt: -1 });
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

// Update user (including role)
router.patch("/users/:id", async (req, res) => {
  try {
    const { name, email, role } = req.body;
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ error: "User not found" });

    if (name) user.name = name;
    if (email) user.email = email.toLowerCase();
    if (role && ["user", "admin"].includes(role)) user.role = role;

    await user.save();
    res.json({ id: user._id, name: user.name, email: user.email, role: user.role });
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

// Delete user
router.delete("/users/:id", async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ error: "User not found" });

    // Prevent deleting yourself
    if (user._id.toString() === req.user.id) {
      return res.status(400).json({ error: "Cannot delete your own account" });
    }

    await User.findByIdAndDelete(req.params.id);
    res.json({ message: "User deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * System-wide Monitoring & Analytics
 */

// Get global stats
router.get("/stats", async (req, res) => {
  try {
    const userCount = await User.countDocuments();
    const projectCount = await Project.countDocuments();
    const bookingCount = await Booking.countDocuments();
    const queryCount = await Query.countDocuments();

    // Calculate global energy/emissions estimates
    const projects = await Project.find();
    let totalKWh = 0;
    projects.forEach(p => {
      const baseHours = p.estimatedActivityHours || 0;
      const taskHours = (p.tasks || []).reduce((sum, t) => sum + (t.estimatedHours || 0), 0);
      totalKWh += (baseHours + taskHours) * 0.5; // Demo factor
    });
    const totalCO2 = totalKWh * 0.4; // Demo factor

    res.json({
      users: userCount,
      projects: projectCount,
      bookings: bookingCount,
      queries: queryCount,
      totalEnergyKWh: totalKWh,
      totalEmissionsKg: totalCO2
    });
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

// Get all projects across the system
router.get("/projects", async (req, res) => {
  try {
    const projects = await Project.find().sort({ createdAt: -1 });
    res.json(projects);
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
