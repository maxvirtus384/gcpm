const mongoose = require("mongoose");

const commentSchema = new mongoose.Schema({
  authorName: { type: String, required: true },
  authorEmail: { type: String, required: true },
  text: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
});

const taskSchema = new mongoose.Schema({
  title: { type: String, required: true },
  assignee: { type: String },
  status: { type: String, enum: ["todo", "in_progress", "done"], default: "todo" },
  estimatedHours: { type: Number },
  deadline: { type: Date },
  files: [{
    name: { type: String },
    url: { type: String },
    uploadedAt: { type: Date, default: Date.now }
  }],
  comments: [commentSchema],
});

const activitySchema = new mongoose.Schema({
  userName: { type: String, required: true },
  action: { type: String, required: true },
  details: { type: String },
  createdAt: { type: Date, default: Date.now },
});

const projectSchema = new mongoose.Schema({
  ownerEmail: { type: String, required: true },
  name: { type: String, required: true },
  description: { type: String },
  estimatedActivityHours: { type: Number, default: 0 },
  deadline: { type: Date },
  githubRepo: { type: String },
  createdAt: { type: Date, default: Date.now },
  tasks: [taskSchema],
  activities: [activitySchema],
});

module.exports = mongoose.model("Project", projectSchema);
