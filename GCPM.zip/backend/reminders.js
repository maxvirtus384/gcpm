const cron = require('node-cron');
const Project = require('./models/Project');

function initReminders() {
  // Check for deadlines every day at 9:00 AM
  cron.schedule('0 9 * * *', async () => {
    console.log('Running daily deadline check...');
    try {
      const now = new Date();
      const threeDaysFromNow = new Date();
      threeDaysFromNow.setDate(now.getDate() + 3);

      const projects = await Project.find({
        deadline: { $lte: threeDaysFromNow, $gte: now }
      });

      projects.forEach(project => {
        // In a real app, send an email or push notification
        console.log(`REMINDER: Project "${project.name}" is due on ${project.deadline.toDateString()}`);
        
        project.activities.push({
          userName: "System",
          action: "Deadline Reminder",
          details: `Project "${project.name}" is due in less than 3 days!`
        });
        project.save();
      });

      // Also check task deadlines
      const projectsWithUpcomingTasks = await Project.find({
        "tasks.deadline": { $lte: threeDaysFromNow, $gte: now }
      });

      projectsWithUpcomingTasks.forEach(project => {
        project.tasks.forEach(task => {
          if (task.deadline <= threeDaysFromNow && task.deadline >= now && task.status !== "done") {
             console.log(`REMINDER: Task "${task.title}" in project "${project.name}" is due on ${task.deadline.toDateString()}`);
             project.activities.push({
                userName: "System",
                action: "Task Deadline Reminder",
                details: `Task "${task.title}" is due soon!`
             });
          }
        });
        project.save();
      });

    } catch (err) {
      console.error('Error in deadline check:', err);
    }
  });
}

module.exports = initReminders;
