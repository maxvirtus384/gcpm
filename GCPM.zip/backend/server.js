require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const mongoose = require("mongoose");

const authRoutes = require("./routes/auth");
const projectRoutes = require("./routes/projects");
const bookingRoutes = require("./routes/bookings");
const queryRoutes = require("./routes/queries");
const adminRoutes = require("./routes/admin");
const initReminders = require("./reminders");

const app = express();
const PORT = process.env.PORT || 3001;
const HOST = process.env.HOST || "0.0.0.0";
const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017/greencode";

// Database connection helper for Serverless
let isConnected = false;
const connectDB = async () => {
  if (isConnected) return;
  try {
    await mongoose.connect(MONGODB_URI);
    isConnected = true;
    console.log("Connected to MongoDB");
    // Only run reminders (cron jobs) if NOT in production (Vercel)
    if (process.env.NODE_ENV !== "production") {
      initReminders();
    }
  } catch (err) {
    console.error("Could not connect to MongoDB:", err);
  }
};

// Middleware to ensure DB connection on every request (essential for Vercel)
app.use(async (req, res, next) => {
  await connectDB();
  next();
});

app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

app.use("/api/auth", authRoutes);
app.use("/api/projects", projectRoutes);
app.use("/api/bookings", bookingRoutes);
app.use("/api/queries", queryRoutes);
app.use("/api/admin", adminRoutes);

app.get("/api/health", (req, res) => {
  res.json({ ok: true, message: "Green Code PM API" });
});

// Serve the frontend (index.html, styles.css, script.js, api.js) from the project root.
// Only do this in local development. Vercel serves static files natively.
if (process.env.NODE_ENV !== "production") {
  const FRONTEND_DIR = path.join(__dirname, "..");
  app.use(express.static(FRONTEND_DIR));

  // Fallback for client-side routes (but never for API routes).
  app.get("*", (req, res, next) => {
    if (req.path.startsWith("/api/")) return next();
    res.sendFile(path.join(FRONTEND_DIR, "index.html"));
  });
}

if (process.env.NODE_ENV !== "production") {
  app.listen(PORT, HOST, () => {
    console.log(`Green Code PM backend running on port ${PORT}`);
  });
}

module.exports = app;
