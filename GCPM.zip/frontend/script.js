// Session and data come from local storage (see api.js)
function getSession() {
  return typeof api !== "undefined" ? api.getSession() : null;
}

function estimateEnergyKWh(project) {
  const baseHours = Number(project.estimatedActivityHours || 0);
  const taskHours = (project.tasks || []).reduce(
    (sum, t) => sum + (Number(t.estimatedHours || 0) || 0),
    0
  );
  const totalHours = baseHours + taskHours;
  const kWhPerHour = 0.5; // demo assumption
  return totalHours * kWhPerHour;
}

function estimateEmissionsKgCO2(energyKWh) {
  const kgPerKWh = 0.4; // demo grid factor
  return energyKWh * kgPerKWh;
}

function calculateCompletion(project) {
  const tasks = project.tasks || [];
  if (!tasks.length) return 0;
  const done = tasks.filter((t) => t.status === "done").length;
  return (done / tasks.length) * 100;
}

function calculateGreenScore(project) {
  const completion = calculateCompletion(project);
  const energy = estimateEnergyKWh(project);
  const emissions = estimateEmissionsKgCO2(energy);
  const emissionsPenalty = Math.min(emissions, 200); // clamp
  const baseScore = 100 - (emissionsPenalty / 200) * 60; // up to -60 pts
  const completionBonus = (completion / 100) * 20; // up to +20 pts
  return Math.max(0, Math.min(100, baseScore + completionBonus));
}

function formatNumber(n, decimals = 1) {
  if (Number.isNaN(n)) return "0";
  return n.toLocaleString(undefined, {
    maximumFractionDigits: decimals,
    minimumFractionDigits: decimals,
  });
}

/**
 * Notification System
 */
function showNotification(message, type = "info") {
  const container = document.getElementById("notification-container") || createNotificationContainer();
  const note = document.createElement("div");
  note.className = `notification notification-${type}`;
  note.textContent = message;
  container.appendChild(note);
  setTimeout(() => note.remove(), 5000);
}

function createNotificationContainer() {
  const div = document.createElement("div");
  div.id = "notification-container";
  div.className = "notification-container";
  document.body.appendChild(div);
  return div;
}

/**
 * GitHub Activity Simulation
 */
async function fetchGithubActivity(repoUrl) {
  if (!repoUrl) return null;
  // Simulating fetching commits from GitHub API
  await new Promise(r => setTimeout(r, 600));
  const commits = Math.floor(Math.random() * 20) + 1;
  return { commits, lastUpdate: new Date().toISOString() };
}

// Simple AI-based prediction (Heuristic: predicts future emissions based on current trend)
function predictFutureEmissions(projects) {
  if (!projects.length) return 0;
  const totalEmissions = projects.reduce((sum, p) => sum + estimateEmissionsKgCO2(estimateEnergyKWh(p)), 0);
  const avgEmissions = totalEmissions / projects.length;
  // Simple heuristic: Predict +15% if tasks are mostly in progress, -10% if mostly done
  return avgEmissions * 1.05; 
}

// Real-time carbon intensity simulation (Simulating an external API like Electricity Maps)
async function fetchCarbonIntensity() {
  // Simulate API delay
  await new Promise(r => setTimeout(r, 500));
  // In a real app, you'd fetch from: https://api.electricitymap.org/v3/carbon-intensity/latest?zone=US-CA
  // We'll return a random realistic value between 150-500 gCO2e/kWh
  const intensity = Math.floor(Math.random() * (500 - 150 + 1)) + 150;
  return intensity;
}

/**
 * UI Enhancements
 */

/**
 * Enhanced Analytics & Charts
 */

let performanceChart = null;
let intensityChart = null;
let comparisonEnergyChart = null;
let comparisonEmissionsChart = null;

async function renderEnhancedCharts(projects) {
  const intensity = await fetchCarbonIntensity();
  const intensityDisplay = document.getElementById("intensity-display");
  if (intensityDisplay) {
    intensityDisplay.textContent = `${intensity} gCO₂e/kWh`;
    intensityDisplay.className = intensity < 300 ? "intensity-low" : intensity < 450 ? "intensity-medium" : "intensity-high";
  }

  renderPerformanceAnalytics(projects);
  renderComparisonCharts(projects);
  renderIntensityHistory(intensity);
}

function renderPerformanceAnalytics(projects) {
  const ctx = document.getElementById("performanceChart");
  if (!ctx || !window.Chart) return;

  const labels = projects.map(p => p.name);
  const scores = projects.map(p => calculateGreenScore(p));
  const predictions = projects.map(p => predictFutureEmissions([p]));

  if (performanceChart) performanceChart.destroy();
  performanceChart = new Chart(ctx, {
    type: 'radar',
    data: {
      labels,
      datasets: [{
        label: 'Current Green Score',
        data: scores,
        backgroundColor: 'rgba(74, 222, 128, 0.2)',
        borderColor: 'var(--accent)',
      }, {
        label: 'Predicted Emission Impact (Scaled)',
        data: predictions.map(v => v * 10), // Scale for radar visibility
        backgroundColor: 'rgba(248, 113, 113, 0.2)',
        borderColor: 'var(--danger)',
      }]
    },
    options: {
      scales: {
        r: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.1)' } }
      }
    }
  });
}

function renderComparisonCharts(projects) {
  const ctxEnergy = document.getElementById("comparisonEnergyChart");
  const ctxEmissions = document.getElementById("comparisonEmissionsChart");
  if (!ctxEnergy || !ctxEmissions || !window.Chart) return;

  const labels = projects.map(p => p.name);
  const energyData = projects.map(p => estimateEnergyKWh(p));
  const emissionsData = projects.map(p => estimateEmissionsKgCO2(estimateEnergyKWh(p)));

  if (comparisonEnergyChart) comparisonEnergyChart.destroy();
  comparisonEnergyChart = new Chart(ctxEnergy, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Energy (kWh)',
        data: energyData,
        backgroundColor: 'var(--accent)',
      }]
    }
  });

  if (comparisonEmissionsChart) comparisonEmissionsChart.destroy();
  comparisonEmissionsChart = new Chart(ctxEmissions, {
    type: 'pie',
    data: {
      labels,
      datasets: [{
        data: emissionsData,
        backgroundColor: projects.map((_, i) => `hsl(${i * 45}, 70%, 50%)`),
      }]
    }
  });
}

let intensityHistory = [];
function renderIntensityHistory(currentIntensity) {
  const ctx = document.getElementById("intensityChart");
  if (!ctx || !window.Chart) return;

  intensityHistory.push(currentIntensity);
  if (intensityHistory.length > 10) intensityHistory.shift();

  if (intensityChart) intensityChart.destroy();
  intensityChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: intensityHistory.map((_, i) => i),
      datasets: [{
        label: 'gCO₂e/kWh',
        data: intensityHistory,
        borderColor: 'var(--amber)',
        tension: 0.4
      }]
    },
    options: {
      plugins: { legend: { display: false } },
      scales: { y: { display: false }, x: { display: false } }
    }
  });
}

function updatePortfolioStats(projectsForUser) {
  const totalProjectsEl = document.getElementById("stat-total-projects");
  const avgScoreEl = document.getElementById("stat-avg-green-score");
  const totalEmissionsEl = document.getElementById("stat-total-emissions");

  const total = projectsForUser.length;
  const scores = projectsForUser.map((p) => calculateGreenScore(p));
  const emissions = projectsForUser.map((p) =>
    estimateEmissionsKgCO2(estimateEnergyKWh(p))
  );

  const avgScore =
    scores.length > 0
      ? scores.reduce((a, b) => a + b, 0) / scores.length
      : 0;
  const totalEmissions =
    emissions.length > 0
      ? emissions.reduce((a, b) => a + b, 0)
      : 0;

  if (totalProjectsEl) totalProjectsEl.textContent = String(total);
  if (avgScoreEl)
    avgScoreEl.textContent = total ? formatNumber(avgScore, 0) : "–";
  if (totalEmissionsEl)
    totalEmissionsEl.textContent = formatNumber(totalEmissions, 1);
}

function renderProjectSelect(projectsForUser, currentProjectId) {
  const select = document.getElementById("project-select");
  if (!select) return;

  select.innerHTML = "";

  if (!projectsForUser.length) {
    const opt = document.createElement("option");
    opt.value = "";
    opt.textContent = "No projects yet";
    select.appendChild(opt);
    select.disabled = true;
    return;
  }

  select.disabled = false;
  projectsForUser.forEach((project, idx) => {
    const opt = document.createElement("option");
    opt.value = project.id;
    opt.textContent = project.name || `Project ${idx + 1}`;
    if (project.id === currentProjectId) opt.selected = true;
    select.appendChild(opt);
  });
}

async function renderTasksForProject(project) {
  const layout = document.getElementById("tasks-layout");
  const summary = document.getElementById("project-summary");
  const kanbanTodo = document.getElementById("kanban-todo");
  const kanbanInProgress = document.getElementById("kanban-in_progress");
  const kanbanDone = document.getElementById("kanban-done");
  
  if (!layout || !summary || !kanbanTodo || !kanbanInProgress || !kanbanDone) return;

  if (!project) {
    layout.hidden = true;
    summary.innerHTML = '<p class="muted">Create a project to see status, tasks, and sustainability metrics.</p>';
    return;
  }

  const tasks = project.tasks || [];
  const completion = calculateCompletion(project);
  const energy = estimateEnergyKWh(project);
  const emissions = estimateEmissionsKgCO2(energy);
  const score = calculateGreenScore(project);

  let githubInfo = "";
  if (project.githubRepo) {
    const activity = await fetchGithubActivity(project.githubRepo);
    githubInfo = `<div class="github-activity" style="margin-top: 0.5rem; font-size: 0.75rem; color: var(--amber);">
      🐙 GitHub: ${activity.commits} commits tracked recently
    </div>`;
  }

  summary.innerHTML = `
    <p>
      <strong>${project.name || "Untitled project"}</strong><br/>
      ${project.description || ""}
    </p>
    ${githubInfo}
    <div class="metrics-row" style="display: flex; gap: 1rem; margin-top: 0.5rem; font-size: 0.85rem;">
      <div class="metric-pill">Completion: ${formatNumber(completion, 0)}%</div>
      <div class="metric-pill">Energy: ${formatNumber(energy, 1)} kWh</div>
      <div class="metric-pill">Emissions: ${formatNumber(emissions, 1)} kg CO₂e</div>
      <div class="metric-pill">Green score: ${formatNumber(score, 0)}/100</div>
    </div>
    ${project.deadline ? `<p style="font-size: 0.75rem; margin-top: 0.5rem; color: var(--danger);">📅 Project Deadline: ${new Date(project.deadline).toLocaleDateString()}</p>` : ""}
  `;

  layout.hidden = false;
  
  // Clear columns
  [kanbanTodo, kanbanInProgress, kanbanDone].forEach(col => col.innerHTML = "");

  tasks.forEach((task) => {
    const card = document.createElement("div");
    card.className = "task-card";
    card.draggable = true;
    card.dataset.taskId = task.id;
    card.dataset.projectId = project.id;
    
    card.innerHTML = `
      <h5>${task.title}</h5>
      <div class="task-meta">
        <span>${task.assignee || "Unassigned"}</span>
        <span>${task.estimatedHours || 0}h</span>
      </div>
      ${task.deadline ? `<div style="font-size: 0.65rem; color: var(--danger); margin-top: 0.2rem;">Due: ${new Date(task.deadline).toLocaleDateString()}</div>` : ""}
      <div class="task-files" style="margin-top: 0.5rem; font-size: 0.7rem;">
        ${(task.files || []).map(f => `<a href="${f.url}" target="_blank" style="display: block; color: var(--accent);">📄 ${f.name}</a>`).join("")}
      </div>
      <button class="task-comments-btn" onclick="openCommentsModal('${project.id}', '${task.id}')">
        💬 ${task.comments ? task.comments.length : 0} comments
      </button>
    `;

    card.addEventListener("dragstart", () => card.classList.add("dragging"));
    card.addEventListener("dragend", () => card.classList.remove("dragging"));

    const columnMap = {
      "todo": kanbanTodo,
      "in_progress": kanbanInProgress,
      "done": kanbanDone
    };
    
    const targetCol = columnMap[task.status] || kanbanTodo;
    targetCol.appendChild(card);
  });

  renderActivityFeed(project.activities);
  renderChat(project.id);
}

function initDragAndDrop() {
  const columns = document.querySelectorAll(".kanban-tasks");
  
  columns.forEach(column => {
    column.addEventListener("dragover", e => {
      e.preventDefault();
      const draggingTask = document.querySelector(".dragging");
      if (draggingTask) column.appendChild(draggingTask);
    });

    column.addEventListener("drop", async e => {
      e.preventDefault();
      const draggingTask = document.querySelector(".dragging");
      if (!draggingTask) return;
      
      const taskId = draggingTask.dataset.taskId;
      const projectId = draggingTask.dataset.projectId;
      const newStatus = column.parentElement.dataset.status;
      
      try {
        await api.updateTask(projectId, taskId, { status: newStatus });
        await refreshDashboard(projectId);
      } catch (err) {
        console.error("Failed to update task status", err);
      }
    });
  });
}

function renderActivityFeed(activities) {
  const feed = document.getElementById("activity-feed");
  if (!feed) return;

  if (!activities || !activities.length) {
    feed.innerHTML = '<p class="muted">No recent activity.</p>';
    return;
  }

  feed.innerHTML = activities.slice().reverse().map(act => `
    <div class="activity-item">
      <strong>${act.userName}</strong> ${act.action}: <em>${act.details || ""}</em>
      <span class="activity-time">${new Date(act.createdAt).toLocaleString()}</span>
    </div>
  `).join("");
}

async function renderChat(projectId) {
  const chatMessages = document.getElementById("chat-messages");
  if (!chatMessages) return;

  try {
    const messages = await api.getProjectChat(projectId);
    const session = getSession();
    
    chatMessages.innerHTML = messages.map(msg => `
      <div class="chat-message ${msg.authorEmail === session.user.email ? 'own' : 'other'}">
        <span class="chat-author">${msg.authorName}</span>
        ${msg.text}
      </div>
    `).join("");
    
    chatMessages.scrollTop = chatMessages.scrollHeight;
  } catch (err) {
    console.error("Failed to fetch chat", err);
  }
}

// Global modal handlers
window.openCommentsModal = async (projectId, taskId) => {
  const modalContainer = document.getElementById("modal-container");
  const session = getSession();
  
  try {
    const projects = await api.getProjects();
    const project = projects.find(p => p.id === projectId);
    const task = project.tasks.find(t => t.id === taskId);
    
    modalContainer.innerHTML = `
      <div class="modal-overlay" onclick="if(event.target === this) this.remove()">
        <div class="modal-content">
          <h4>Comments: ${task.title}</h4>
          <div class="comments-list" style="margin: 1rem 0; max-height: 200px; overflow-y: auto;">
            ${(task.comments || []).map(c => `
              <div style="font-size: 0.8rem; margin-bottom: 0.5rem; border-bottom: 1px solid rgba(255,255,255,0.05);">
                <strong>${c.authorName}</strong>: ${c.text}
                <div style="color: var(--muted); font-size: 0.7rem;">${new Date(c.createdAt).toLocaleString()}</div>
              </div>
            `).join("") || '<p class="muted">No comments yet.</p>'}
          </div>
          <form id="comment-form">
            <textarea id="comment-text" required placeholder="Add a comment..." style="width:100%; background:rgba(0,0,0,0.2); border:1px solid var(--border-subtle); color:#fff; padding:0.5rem; border-radius:8px;"></textarea>
            <button type="submit" class="btn btn-small" style="margin-top:0.5rem;">Post Comment</button>
          </form>
        </div>
      </div>
    `;

    document.getElementById("comment-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      const text = document.getElementById("comment-text").value;
      await api.addTaskComment(projectId, taskId, text);
      modalContainer.innerHTML = "";
      await refreshDashboard(projectId);
    });
  } catch (err) {
    console.error("Failed to open comments", err);
  }
};

async function getProjectsForUser() {
  if (typeof api === "undefined") return [];
  try {
    return await api.getProjects();
  } catch (err) {
    if (err.status === 401) {
      api.logout();
      await handleAuthVisibility();
    }
    return [];
  }
}

async function markTaskDone(projectId, taskId) {
  if (typeof api === "undefined") return;
  try {
    await api.updateTask(projectId, taskId, { status: "done" });
    await refreshDashboard();
  } catch (err) {
    if (err.status === 401) {
      api.logout();
      await handleAuthVisibility();
    }
    const errorEl = document.getElementById("task-error");
    if (errorEl) errorEl.textContent = err?.data?.error || err?.message || "Failed to update task.";
  }
}

let isRefreshing = false;

async function refreshDashboard(selectedProjectId) {
  if (isRefreshing) return;
  const session = getSession();
  if (!session) return;

  isRefreshing = true;
  try {
    const projectsForUser = await getProjectsForUser();
    // After async call, re-check session in case it was cleared by 401
    const currentSession = getSession();
    if (!currentSession) return;

    const currentId =
      selectedProjectId ||
      (projectsForUser[0] ? projectsForUser[0].id : undefined);

    updatePortfolioStats(projectsForUser);
    renderProjectSelect(projectsForUser, currentId);

    const currentProject = projectsForUser.find((p) => p.id === currentId);
    await renderTasksForProject(currentProject || null);
    renderEnhancedCharts(projectsForUser);
  } finally {
    isRefreshing = false;
  }
}

function switchAuthMode(mode) {
  const loginForm = document.getElementById("login-form");
  const registerForm = document.getElementById("register-form");
  const loginTab = document.getElementById("login-tab");
  const registerTab = document.getElementById("register-tab");
  const roleSelector = document.querySelector(".role-selector");
  if (!loginForm || !registerForm || !loginTab || !registerTab) return;

  if (mode === "login") {
    loginForm.classList.remove("auth-form-hidden");
    registerForm.classList.add("auth-form-hidden");
    loginTab.classList.add("auth-tab-active");
    registerTab.classList.remove("auth-tab-active");
    if (roleSelector) roleSelector.style.display = "flex";
  } else {
    loginForm.classList.add("auth-form-hidden");
    registerForm.classList.remove("auth-form-hidden");
    loginTab.classList.remove("auth-tab-active");
    registerTab.classList.add("auth-tab-active");
    if (roleSelector) roleSelector.style.display = "none";
  }
}

async function handleAuthVisibility() {
  const session = getSession();
  const authCard = document.getElementById("auth-card");
  const appShell = document.getElementById("app-shell");
  const adminShell = document.getElementById("admin-shell");
  const nameEl = document.getElementById("current-user-name");
  const nameNavEl = document.getElementById("current-user-name-nav");
  const authNav = document.getElementById("auth-nav");
  const appContainer = document.getElementById("app-container");
  const navContainer = document.getElementById("nav-container");

  if (!authCard || !appShell || !adminShell) return;

  if (session) {
    authCard.style.display = "none";
    if (appContainer) appContainer.classList.add("container-wide");
    if (adminShell) adminShell.classList.add("container-wide");
    if (navContainer) navContainer.classList.add("container-wide");
    
    if (session.user.role === "admin") {
      appShell.hidden = true;
      adminShell.hidden = false;
    } else {
      appShell.hidden = false;
      adminShell.hidden = true;
    }
    const displayName = session.user.name || session.user.email;
    if (nameEl) nameEl.textContent = displayName;
    if (nameNavEl) nameNavEl.textContent = displayName;
    if (authNav) authNav.hidden = false;
  } else {
    authCard.style.display = "";
    if (appContainer) appContainer.classList.remove("container-wide");
    if (adminShell) adminShell.classList.remove("container-wide");
    if (navContainer) navContainer.classList.remove("container-wide");
    
    appShell.hidden = true;
    adminShell.hidden = true;
    if (nameEl) nameEl.textContent = "";
    if (nameNavEl) nameNavEl.textContent = "";
    if (authNav) authNav.hidden = true;
  }
}

async function refreshAdminDashboard() {
  const usersTable = document.getElementById("admin-users-table");
  const bookingsTable = document.getElementById("admin-bookings-table");
  const queriesTable = document.getElementById("admin-queries-table");
  
  try {
    const stats = await api.getAdminStats();
    const users = await api.getAdminUsers();
    const bookings = await api.getAdminBookings();
    const queries = await api.getAdminQueries();
    const allProjects = await api.getAdminProjects();
    
    if (usersTable) {
      usersTable.innerHTML = users.map(u => `
        <tr>
          <td>${u.name}</td>
          <td>${u.email}</td>
          <td>
            <select class="role-select" onchange="updateUserRole('${u._id || u.id}', this.value)">
              <option value="user" ${u.role === 'user' ? 'selected' : ''}>User</option>
              <option value="admin" ${u.role === 'admin' ? 'selected' : ''}>Admin</option>
            </select>
          </td>
          <td>${new Date(u.createdAt).toLocaleDateString()}</td>
          <td>
            <button class="btn btn-small btn-ghost" onclick="deleteUser('${u._id || u.id}')" style="color: var(--color-error);">Delete</button>
          </td>
        </tr>
      `).join("");
    }

    if (bookingsTable) {
      bookingsTable.innerHTML = bookings.map(b => `
        <tr>
          <td>${b.name}</td>
          <td>${b.email}</td>
          <td>${b.company || "—"}</td>
          <td>${b.timeline || "—"}</td>
        </tr>
      `).join("");
    }
    
    if (queriesTable) {
      queriesTable.innerHTML = queries.map(q => `
        <tr>
          <td>${q.name}</td>
          <td>${q.email}</td>
          <td>${q.message}</td>
        </tr>
      `).join("");
    }

    renderAdminCharts(allProjects);
  } catch (err) {
    if (err.status === 401) {
      api.logout();
      await handleAuthVisibility();
    }
    console.error("Admin refresh failed", err);
  }
}

// Global functions for Admin actions
window.updateUserRole = async (userId, newRole) => {
  try {
    await api.updateAdminUser(userId, { role: newRole });
    showNotification("User role updated", "success");
    await refreshAdminDashboard();
  } catch (err) {
    showNotification("Failed to update role", "error");
  }
};

window.deleteUser = async (userId) => {
  if (!confirm("Are you sure you want to delete this user?")) return;
  try {
    await api.deleteAdminUser(userId);
    showNotification("User deleted", "success");
    await refreshAdminDashboard();
  } catch (err) {
    showNotification(err.data?.error || "Failed to delete user", "error");
  }
};

let adminEnergyChart = null;
let adminEmissionsChart = null;

function renderAdminCharts(projects) {
  const ctxEnergy = document.getElementById("adminEnergyChart");
  const ctxEmissions = document.getElementById("adminEmissionsChart");
  if (!ctxEnergy || !ctxEmissions || !window.Chart) return;

  const labels = projects.map(p => p.name);
  const energy = projects.map(p => estimateEnergyKWh(p));
  const emissions = projects.map(p => estimateEmissionsKgCO2(estimateEnergyKWh(p)));

  if (adminEnergyChart) adminEnergyChart.destroy();
  if (adminEmissionsChart) adminEmissionsChart.destroy();

  adminEnergyChart = new Chart(ctxEnergy, {
    type: "bar",
    data: {
      labels,
      datasets: [{
        label: "Energy (kWh)",
        data: energy,
        backgroundColor: "rgba(74, 222, 128, 0.6)",
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true, ticks: { color: "#9ca3af" } }, x: { ticks: { color: "#9ca3af" } } }
    }
  });

  adminEmissionsChart = new Chart(ctxEmissions, {
    type: "bar",
    data: {
      labels,
      datasets: [{
        label: "Emissions (kg CO₂e)",
        data: emissions,
        backgroundColor: "rgba(248, 113, 113, 0.6)",
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true, ticks: { color: "#9ca3af" } }, x: { ticks: { color: "#9ca3af" } } }
    }
  });
}

function initAuthHandlers() {
  const loginTab = document.getElementById("login-tab");
  const registerTab = document.getElementById("register-tab");
  const loginForm = document.getElementById("login-form");
  const registerForm = document.getElementById("register-form");
  const logoutBtn = document.getElementById("logout-btn");
  const logoutBtnNav = document.getElementById("logout-btn-nav");

  if (loginTab) {
    loginTab.addEventListener("click", () => switchAuthMode("login"));
  }
  if (registerTab) {
    registerTab.addEventListener("click", () => switchAuthMode("register"));
  }

  if (loginForm) {
    loginForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const email = document.getElementById("login-email").value
        .trim()
        .toLowerCase();
      const password = document.getElementById("login-password").value.trim();
      const errorEl = document.getElementById("login-error");
      if (errorEl) errorEl.textContent = "";

      try {
        const session = await api.login(email, password);
        const selectedRole = document.querySelector('input[name="login-role"]:checked')?.value;
        
        if (selectedRole && session.user.role !== selectedRole) {
          api.logout();
          if (errorEl) errorEl.textContent = `Access denied. You are logged into the ${selectedRole === 'admin' ? 'Admin' : 'User'} portal, but your account is for a ${session.user.role}.`;
          return;
        }

        if (loginForm) loginForm.reset();
        await handleAuthVisibility();
        if (session.user.role === "admin") {
          await refreshAdminDashboard();
        } else {
          await refreshDashboard();
        }
      } catch (err) {
        if (errorEl) errorEl.textContent = err?.data?.error || err?.message || "Invalid email or password.";
      }
    });
  }

  if (registerForm) {
    registerForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const name = document.getElementById("register-name").value.trim();
      const email = document.getElementById("register-email").value
        .trim()
        .toLowerCase();
      const password = document.getElementById("register-password").value.trim();
      const role = document.querySelector('input[name="register-role"]:checked')?.value || "user";
      const errorEl = document.getElementById("register-error");
      if (errorEl) errorEl.textContent = "";

      if (!name || !email || !password) {
        if (errorEl) errorEl.textContent = "All fields are required.";
        return;
      }

      try {
        const session = await api.register(name, email, password, role);
        if (registerForm) registerForm.reset();
        switchAuthMode("login");
        await handleAuthVisibility();
        if (session.user.role === "admin") {
          await refreshAdminDashboard();
        } else {
          await refreshDashboard();
        }
      } catch (err) {
        if (errorEl) errorEl.textContent = err?.data?.error || err?.message || "Registration failed.";
      }
    });
  }

  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      api.logout();
      handleAuthVisibility();
    });
  }

  if (logoutBtnNav) {
    logoutBtnNav.addEventListener("click", () => {
      api.logout();
      handleAuthVisibility();
    });
  }
}

function initProjectHandlers() {
  const projectForm = document.getElementById("project-form");
  const projectSelect = document.getElementById("project-select");
  const taskForm = document.getElementById("task-form");
  const downloadBtn = document.getElementById("download-report-btn");
  const chatForm = document.getElementById("chat-form");
  const chatInput = document.getElementById("chat-input");

  if (chatForm) {
    chatForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const projectId = projectSelect.value;
      const text = chatInput.value;
      if (!projectId || !text) return;
      
      try {
        await api.sendProjectChat(projectId, text);
        chatInput.value = "";
        await renderChat(projectId);
      } catch (err) {
        console.error("Chat send failed", err);
      }
    });
  }

  if (projectForm) {
    projectForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const session = getSession();
      if (!session) return;

      const name = document.getElementById("project-name").value.trim();
      const description =
        document.getElementById("project-description").value.trim();
      const activityRaw =
        document.getElementById("project-activity").value.trim();
      const activity = activityRaw ? Number(activityRaw) : 0;
      const deadline = document.getElementById("project-deadline").value;
      const githubRepo = document.getElementById("project-github").value.trim();
      const errorEl = document.getElementById("project-error");
      if (errorEl) errorEl.textContent = "";

      if (!name) {
        if (errorEl) errorEl.textContent = "Project name is required.";
        return;
      }

      try {
        const newProject = await api.createProject({
          name,
          description,
          activity: activity || 0,
          deadline,
          githubRepo
        });
        projectForm.reset();
        showNotification(`Project "${name}" created successfully!`, "success");
        await refreshDashboard(newProject.id);
      } catch (err) {
        if (errorEl) errorEl.textContent = err?.data?.error || err?.message || "Failed to create project.";
      }
    });
  }

  if (projectSelect) {
    projectSelect.addEventListener("change", async () => {
      const session = getSession();
      if (!session) return;
      const projectsForUser = await getProjectsForUser();
      const currentId = projectSelect.value;
      const project = projectsForUser.find((p) => p.id === currentId);
      await renderTasksForProject(project || null);
    });
  }

  // Auto-refresh chat
  setInterval(() => {
    const session = getSession();
    if (session && session.user.role !== "admin") {
      const projectId = document.getElementById("project-select")?.value;
      if (projectId) renderChat(projectId);
    }
  }, 5000);

  if (taskForm) {
    taskForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const session = getSession();
      if (!session) return;

      const projectSelectEl = document.getElementById("project-select");
      const projectId = projectSelectEl ? projectSelectEl.value : "";
      const errorEl = document.getElementById("task-error");
      if (errorEl) errorEl.textContent = "";

      if (!projectId) {
        if (errorEl)
          errorEl.textContent = "Select a project before adding tasks.";
        return;
      }

      const title = document.getElementById("task-title").value.trim();
      const assignee = document.getElementById("task-assignee").value.trim();
      const status = document.getElementById("task-status").value;
      const hoursRaw = document.getElementById("task-hours").value.trim();
      const hours = hoursRaw ? Number(hoursRaw) : null;
      const deadline = document.getElementById("task-deadline").value;
      const fileInput = document.getElementById("task-file");

      if (!title) {
        if (errorEl) errorEl.textContent = "Task title is required.";
        return;
      }

      const formData = new FormData();
      formData.append("title", title);
      formData.append("assignee", assignee);
      formData.append("status", status);
      if (hours !== null) formData.append("hours", hours);
      if (deadline) formData.append("deadline", deadline);
      if (fileInput && fileInput.files[0]) {
        formData.append("file", fileInput.files[0]);
      }

      try {
        await api.addTask(projectId, formData);
        taskForm.reset();
        showNotification(`Task "${title}" added!`, "success");
        await refreshDashboard(projectId);
      } catch (err) {
        if (errorEl) errorEl.textContent = err?.data?.error || err?.message || "Failed to add task.";
      }
    });
  }

  if (downloadBtn) {
    downloadBtn.addEventListener("click", async () => {
      const session = getSession();
      if (!session) return;
      const projects = await getProjectsForUser();
      const lines = ["Green Code PM - Sustainability Report", `User: ${session.user.name}`, ""];
      projects.forEach(p => {
        lines.push(`${p.name}: Energy: ${formatNumber(estimateEnergyKWh(p))} kWh, Emissions: ${formatNumber(estimateEmissionsKgCO2(estimateEnergyKWh(p)))} kg CO2e, Score: ${formatNumber(calculateGreenScore(p), 0)}/100`);
      });
      const blob = new Blob([lines.join("\n")], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "report.txt";
      a.click();
    });
  }

  if (exportPdfBtn) {
    exportPdfBtn.addEventListener("click", async () => {
      const session = getSession();
      if (!session) return;
      const projects = await getProjectsForUser();
      
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF();
      
      doc.setFontSize(22);
      doc.text("Green Code PM - Sustainability Report", 20, 20);
      doc.setFontSize(12);
      doc.text(`Generated on: ${new Date().toLocaleString()}`, 20, 30);
      doc.text(`User: ${session.user.name}`, 20, 37);
      
      let y = 50;
      projects.forEach((p, idx) => {
        if (y > 250) {
          doc.addPage();
          y = 20;
        }
        doc.setFontSize(16);
        doc.text(`${idx + 1}. ${p.name}`, 20, y);
        y += 7;
        doc.setFontSize(10);
        doc.text(`Description: ${p.description || 'N/A'}`, 25, y);
        y += 5;
        doc.text(`Energy: ${formatNumber(estimateEnergyKWh(p))} kWh`, 25, y);
        y += 5;
        doc.text(`Emissions: ${formatNumber(estimateEmissionsKgCO2(estimateEnergyKWh(p)))} kg CO2e`, 25, y);
        y += 5;
        doc.text(`Green Score: ${formatNumber(calculateGreenScore(p), 0)}/100`, 25, y);
        y += 15;
      });
      
      doc.save("green-code-report.pdf");
    });
  }
}

function buildContactMailtoUrl() {
  const to = "maxvirtus384@gmail.com";
  const name = (document.getElementById("name")?.value || "").trim();
  const email = (document.getElementById("email")?.value || "").trim();
  const company = (document.getElementById("company")?.value || "").trim();
  const message = (document.getElementById("message")?.value || "").trim();
  const timeline = (document.getElementById("timeline")?.value || "").trim();

  const subject = "Green Code PM — Inquiry";
  const lines = [];
  if (name) lines.push(`Name: ${name}`);
  if (email) lines.push(`Email: ${email}`);
  if (company) lines.push(`Organization: ${company}`);
  if (timeline) lines.push(`Ideal start date: ${timeline}`);
  lines.push("");
  lines.push(message || "(no message)");

  const body = lines.join("\n");
  return `mailto:${to}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

async function copyContactMessageToClipboard() {
  const url = buildContactMailtoUrl();
  const decodedBody = decodeURIComponent(url.split("&body=")[1] || "");
  if (navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(decodedBody);
  } else {
    // Fallback for older browsers.
    const ok = window.prompt("Copy this message:", decodedBody);
    if (ok === null) return false;
  }
  return true;
}

function initContactHandlers() {
  const contactForm = document.getElementById("contact-form");
  const fallback = document.getElementById("contact-fallback");
  const copyBtn = document.getElementById("copy-contact-btn");

  if (copyBtn) {
    copyBtn.addEventListener("click", async () => {
      try {
        const ok = await copyContactMessageToClipboard();
        if (ok) copyBtn.textContent = "Copied";
        setTimeout(() => {
          copyBtn.textContent = "Copy message";
        }, 1500);
      } catch {
        if (fallback) fallback.hidden = false;
      }
    });
  }

  if (!contactForm) return;
  contactForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const name = document.getElementById("name")?.value;
    const email = document.getElementById("email")?.value;
    const company = document.getElementById("company")?.value;
    const message = document.getElementById("message")?.value;
    const timeline = document.getElementById("timeline")?.value;

    const submitBtn = contactForm.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = "Submitting...";

    try {
      // 1. Save to database for Admin visibility
      if (timeline) {
        await api.bookDiscoveryCall({ name, email, company, message, timeline });
      } else {
        await api.submitQuery({ name, email, message });
      }
      
      // 2. Construct and trigger mailto link to send the email
      const mailtoUrl = buildContactMailtoUrl();
      window.location.assign(mailtoUrl);

      alert("Thank you! Your request has been received and your email client should open shortly.");
      contactForm.reset();
    } catch (err) {
      alert("Failed to submit: " + (err.message || "Internal error"));
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = originalText;
    }
  });
}

document.addEventListener("DOMContentLoaded", async function () {
  const el = document.getElementById("year");
  if (el) {
    el.textContent = new Date().getFullYear();
  }

  initAuthHandlers();
  initProjectHandlers();
  initContactHandlers();
  initDragAndDrop();
  await handleAuthVisibility();
  
  const session = getSession();
  if (session) {
    if (session.user.role === "admin") {
      await refreshAdminDashboard();
    } else {
      await refreshDashboard();
    }
  }
});

